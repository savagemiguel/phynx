<?php
require_once '../config.php';
require_once '../includes/functions.php';
requireAdmin();

// Get statistics
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'user'");
$totalUsers = mysqli_fetch_assoc($result)['count'];

$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM domains");
$totalDomains = mysqli_fetch_assoc($result)['count'];

$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM packages WHERE status = 'active'");
$totalPackages = mysqli_fetch_assoc($result)['count'];

$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE status = 'pending'");
$pendingUsers = mysqli_fetch_assoc($result)['count'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Hosting Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script defer src="../assets/js/sidebar.js"></script>
</head>
<body>
    <?php require_once '../includes/admin_sidebar.php'; ?>
    
    <div class="main-content">
        <h1>Dashboard</h1>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $totalUsers ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $totalDomains ?></div>
                <div class="stat-label">Total Domains</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $totalPackages ?></div>
                <div class="stat-label">Active Packages</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $pendingUsers ?></div>
                <div class="stat-label">Pending Users</div>
            </div>
        </div>
        
        <div class="card">
            <h3>Recent Users</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT id, username, email, status, created_at FROM users WHERE role = 'user' ORDER BY created_at DESC LIMIT 5");
                    while ($user = mysqli_fetch_assoc($result)):
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= ucfirst($user['status']) ?></td>
                        <td><?= date('M j, Y', strtotime($user['created_at'])) ?></td>
                        <td class="actions-cell">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <a href="users.php?edit=<?= $user['id'] ?>" class="btn btn-primary" style="padding: 6px 16px; font-size: 12px; height: 32px; display: inline-flex; align-items: center;">Edit</a>
                                <form method="POST" action="users.php" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user?')">
                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                    <button type="submit" name="delete_user" class="btn btn-danger" style="padding: 6px 16px; font-size: 12px; height: 32px;">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>