<?php
require_once '../config.php';
require_once '../includes/functions.php';
require_once '../includes/docker.php';
requireAdmin();

$message = '';
$notices = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_verify()) {
    http_response_code(400);
    exit('Invalid CSRF token');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pull image
    if (isset($_POST['pull_image'])) {
        $name = trim($_POST['image_name'] ?? '');
        if ($name === '') {
            $notices[] = '[ERR] Image name cannot be empty';
        } else {
            [$rc, $out, $cmd] = docker_cmd(['pull', $name]);
            $notices[] = ($rc === 0 ? '[OK] Pulled: ' : '[ERR] Pull failed: ') . htmlspecialchars($name);
            foreach ($out as $line) { $notices[] = '  ' . $line; }
        }
    }
    // Delete image by ID
    if (isset($_POST['delete_image'])) {
        $id = trim($_POST['image_id'] ?? '');
        if ($id === '') {
            $notices[] = '[ERR] Missing image id';
        } else {
            [$rc, $out, $cmd] = docker_cmd(['image', 'rm', $id]);
            $notices[] = ($rc === 0 ? '[OK] Removed image: ' : '[ERR] Remove failed: ') . htmlspecialchars($id);
            foreach ($out as $line) { $notices[] = '  ' . $line; }
        }
    }
}

$images = docker_images();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Docker Images - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script defer src="../assets/js/sidebar.js"></script>
</head>
<body>
<div class="sidebar">
    <div style="padding: 24px; border-bottom: 1px solid var(--border-color);">
        <h3 style="color: var(--primary-color);">Admin Panel</h3>
    </div>
    <div class="sidebar-nav">
        <div class="sidebar-group" data-group-key="admin-overview">
            <div class="group-header" role="button" aria-expanded="false">
                <span class="group-label">Overview</span>
                <span class="group-arrow">▶</span>
            </div>
            <div class="group-items">
                <ul class="sidebar-nav">
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="migrations.php">Migrations</a></li>
                </ul>
            </div>
        </div>

        <div class="sidebar-group" data-group-key="admin-users">
            <div class="group-header" role="button" aria-expanded="false">
                <span class="group-label">Users</span>
                <span class="group-arrow">▶</span>
            </div>
            <div class="group-items">
                <ul class="sidebar-nav">
                    <li><a href="users.php">Users</a></li>
                    <li><a href="packages.php">Packages</a></li>
                </ul>
            </div>
        </div>

        <div class="sidebar-group open" data-group-key="admin-hosting">
            <div class="group-header" role="button" aria-expanded="true">
                <span class="group-label">Hosting</span>
                <span class="group-arrow">▶</span>
            </div>
            <div class="group-items">
                <ul class="sidebar-nav">
                    <li><a href="domains.php">Domains</a></li>
                    <li><a href="database-manager.php">Database Manager</a></li>
                    <li><a href="docker.php">Docker</a></li>
                    <li><a href="docker-images.php" class="active">Docker Images</a></li>
                    <li><a href="ssl-automation.php">SSL Automation</a></li>
                </ul>
            </div>
        </div>

        <div class="sidebar-group" data-group-key="admin-email">
            <div class="group-header" role="button" aria-expanded="false">
                <span class="group-label">Email</span>
                <span class="group-arrow">▶</span>
            </div>
            <div class="group-items">
                <ul class="sidebar-nav">
                    <li><a href="email-manager.php">Email Manager</a></li>
                    <li><a href="email-queue.php">Email Queue</a></li>
                </ul>
            </div>
        </div>

        <div class="sidebar-group" data-group-key="admin-session">
            <div class="group-header" role="button" aria-expanded="false">
                <span class="group-label">Session</span>
                <span class="group-arrow">▶</span>
            </div>
            <div class="group-items">
                <ul class="sidebar-nav">
                    <li><a href="../logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="main-content">
    <h1>Docker Images</h1>

    <?php if (!empty($notices)): ?>
        <div class="card"><pre style="white-space: pre-wrap; font-family: monospace; font-size: 12px; background: var(--bg-tertiary); padding: 12px; border-radius: 6px;"><?= htmlspecialchars(implode("\n", $notices)) ?></pre></div>
    <?php endif; ?>

    <div class="card">
        <h3>Pull Image</h3>
        <form method="POST">
            <?php csrf_field(); ?>
            <div style="display: flex; gap: 12px; align-items: center;">
                <input type="text" class="form-control" name="image_name" placeholder="e.g., nginx:latest" style="max-width: 320px;">
                <button class="btn btn-primary" name="pull_image" value="1" type="submit">Pull</button>
            </div>
        </form>
    </div>

    <div class="card">
        <h3>Local Images</h3>
        <?php if ($images['ok'] && !empty($images['images'])): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Repository</th>
                        <th>Tag</th>
                        <th>Image ID</th>
                        <th>Size</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($images['images'] as $img): ?>
                    <tr>
                        <td><?= htmlspecialchars($img['Repository'] ?? '') ?></td>
                        <td><?= htmlspecialchars($img['Tag'] ?? '') ?></td>
                        <td><?= htmlspecialchars($img['ID'] ?? '') ?></td>
                        <td><?= htmlspecialchars($img['Size'] ?? '') ?></td>
                        <td><?= htmlspecialchars($img['CreatedSince'] ?? '') ?></td>
                        <td>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Remove this image?')">
                                <?php csrf_field(); ?>
                                <input type="hidden" name="image_id" value="<?= htmlspecialchars($img['ID'] ?? '') ?>">
                                <button class="btn btn-danger" name="delete_image" value="1" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="color: var(--text-secondary);">No images found or cannot access Docker.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
