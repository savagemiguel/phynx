<?php
require_once __DIR__ . '/includes/env.php';
// Load .env from project root if present
load_env(__DIR__ . '/.env');

define('DB_HOST', env('DB_HOST', 'localhost'));
define('DB_USER', env('DB_USER', 'root'));
define('DB_PASS', env('DB_PASS', ''));
define('DB_NAME', env('DB_NAME', 'hosting_panel'));

define('SITE_URL', env('SITE_URL', 'http://localhost/phynx/hosting-panel'));
define('ADMIN_EMAIL', env('ADMIN_EMAIL', 'admin@example.com'));

// Server paths
define('APACHE_VHOST_PATH', env('APACHE_VHOST_PATH', 'C:/wamp64/bin/apache/apache2.4.62.1/conf/extra'));
define('DNS_ZONE_PATH', rtrim(env('DNS_ZONE_PATH', 'C:/dns/zones'), "/\\") . '/');
define('WEB_ROOT', rtrim(env('WEB_ROOT', 'C:/wamp64/www/'), "/\\") . '/');

// Session hardening
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
} else {
    // Best-effort for older PHP
    session_set_cookie_params(0, '/; samesite=Lax', '', $secure, true);
}
session_name('phynx_session');
session_start();

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>