<?php
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: index.php');
        exit;
    }
}

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// CSRF protection helpers
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

function csrf_verify() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return true;
    $token = $_POST['csrf_token'] ?? '';
    $sessionToken = $_SESSION['csrf_token'] ?? '';
    return is_string($token) && is_string($sessionToken) && hash_equals($sessionToken, $token);
}

function createVirtualHost($domain, $document_root) {
    $vhost_config = "\n<VirtualHost *:80>\n";
    $vhost_config .= "    ServerName $domain\n";
    $vhost_config .= "    ServerAlias www.$domain\n";
    $vhost_config .= "    DocumentRoot \"$document_root\"\n";
    $vhost_config .= "    ErrorLog \"logs/$domain-error.log\"\n";
    $vhost_config .= "    CustomLog \"logs/$domain-access.log\" common\n";
    $vhost_config .= "</VirtualHost>\n";
    
    file_put_contents(APACHE_VHOST_PATH, $vhost_config, FILE_APPEND);
    return true;
}

function createDNSZoneFile($domain, $records) {
    if (!is_dir(DNS_ZONE_PATH)) {
        mkdir(DNS_ZONE_PATH, 0755, true);
    }
    
    $zoneContent = ";; Zone file for $domain\n";
    $zoneContent .= "\$TTL 3600\n";
    $zoneContent .= "$domain. IN SOA ns1.$domain. admin.$domain. (\n";
    $zoneContent .= "    " . date('Ymd') . "01 ; Serial\n";
    $zoneContent .= "    3600       ; Refresh\n";
    $zoneContent .= "    1800       ; Retry\n";
    $zoneContent .= "    604800     ; Expire\n";
    $zoneContent .= "    86400 )    ; Minimum TTL\n\n";
    
    foreach ($records as $record) {
        $name = $record['name'] === '@' ? $domain . '.' : $record['name'] . '.' . $domain . '.';
        $zoneContent .= sprintf("%-30s %d IN %s %s\n", 
            $name, 
            $record['ttl'], 
            $record['record_type'], 
            $record['value']
        );
    }
    
    $filename = DNS_ZONE_PATH . $domain . '.zone';
    file_put_contents($filename, $zoneContent);
    return true;
}

function getUserPackage($conn, $userId) {
    // Allow accidental reversed arguments: getUserPackage($userId, $conn)
    if (is_int($conn) && $userId instanceof mysqli) {
        [$conn, $userId] = [$userId, $conn];
    }

    // Basic validation/cast
    $userId = (int) $userId;
    if (!($conn instanceof mysqli)) {
        return null;
    }

    $query = "SELECT p.* FROM packages p JOIN users u ON p.id = u.package_id WHERE u.id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        return null;
    }
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return $result ? mysqli_fetch_assoc($result) : null;
}

function getUserDomainCount($conn, $userId) {
    // Allow accidental reversed arguments: getUserDomainCount($userId, $conn)
    if (is_int($conn) && $userId instanceof mysqli) {
        [$conn, $userId] = [$userId, $conn];
    }

    $userId = (int) $userId;
    if (!($conn instanceof mysqli)) {
        return 0;
    }

    $query = "SELECT COUNT(*) as count FROM domains WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        return 0;
    }
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : ['count' => 0];
    return (int) $row['count'];
}

function formatBytes($size, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
        $size /= 1024;
    }
    return round($size, $precision) . ' ' . $units[$i];
}

function createDirectory($path) {
    if (!is_dir($path)) {
        mkdir($path, 0755, true);
        return true;
    }
    return false;
}

function generatePassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    return substr(str_shuffle($chars), 0, $length);
}

function createDatabase($dbName, $dbUser, $dbPass, $conn) {
    $query = "CREATE DATABASE `$dbName`";
    if (mysqli_query($conn, $query)) {
        $query = "CREATE USER '$dbUser'@'localhost' IDENTIFIED BY '$dbPass'";
        mysqli_query($conn, $query);
        $query = "GRANT ALL PRIVILEGES ON `$dbName`.* TO '$dbUser'@'localhost'";
        mysqli_query($conn, $query);
        mysqli_query($conn, "FLUSH PRIVILEGES");
        return true;
    }
    return false;
}
?>