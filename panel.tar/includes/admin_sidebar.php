<?php
// Reusable Admin Sidebar with grouped, collapsible sections
// Auto-detect current file to highlight active link
$current = basename($_SERVER['SCRIPT_NAME']);
function is_active($file) { global $current; return $current === $file ? 'class="active"' : ''; }
?>
<div class="sidebar">
  <div style="padding: 24px; border-bottom: 1px solid var(--border-color);">
    <h3 style="color: var(--primary-color);">Admin Panel</h3>
  </div>
  <div class="sidebar-nav">
    <div class="sidebar-group" data-group-key="admin-overview">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Overview</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="index.php" <?= is_active('index.php') ?>>Dashboard</a></li>
          <li><a href="migrations.php" <?= is_active('migrations.php') ?>>Migrations</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-users">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Users</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="users.php" <?= is_active('users.php') ?>>Users</a></li>
          <li><a href="packages.php" <?= is_active('packages.php') ?>>Packages</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-hosting">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Hosting</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="domains.php" <?= is_active('domains.php') ?>>Domains</a></li>
          <li><a href="database-manager.php" <?= is_active('database-manager.php') ?>>Database Manager</a></li>
          <li><a href="docker.php" <?= is_active('docker.php') ?>>Docker</a></li>
          <li><a href="docker-images.php" <?= is_active('docker-images.php') ?>>Docker Images</a></li>
          <li><a href="docker-templates.php" <?= is_active('docker-templates.php') ?>>Docker Templates</a></li>
          <li><a href="ssl-automation.php" <?= is_active('ssl-automation.php') ?>>SSL Automation</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-email">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Email</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="email-manager.php" <?= is_active('email-manager.php') ?>>Email Manager</a></li>
          <li><a href="email-queue.php" <?= is_active('email-queue.php') ?>>Email Queue</a></li>
          <li><a href="create-email.php" <?= is_active('create-email.php') ?>>Create Email</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-server">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Server Settings</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="setup.php" <?= is_active('setup.php') ?>>DB Setup</a></li>
          <li><a href="general-settings.php" <?= is_active('general-settings.php') ?>>General Settings</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-web">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Web Server Settings</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="ssl-automation.php" <?= is_active('ssl-automation.php') ?>>SSL Automation</a></li>
          <li><a href="vhost-templates.php" <?= is_active('vhost-templates.php') ?>>VHost Templates</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-php">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">PHP Settings</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="php-settings.php" <?= is_active('php-settings.php') ?>>PHP Settings</a></li>
          <li><a href="#">PHP Versions (coming soon)</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-ssh">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">SSH Settings</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="#">SSH Access (coming soon)</a></li>
          <li><a href="#">Authorized Keys (coming soon)</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-services">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Services Config</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="database-manager.php" <?= is_active('database-manager.php') ?>>Database Manager</a></li>
          <li><a href="#">Apache/Nginx (coming soon)</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-dns">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">DNS Functions</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="domains.php" <?= is_active('domains.php') ?>>Domains (per-domain DNS)</a></li>
          <li><a href="#">Zone Templates (coming soon)</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-security">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Security Functions</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="#">2FA, IP Allowlist (coming soon)</a></li>
          <li><a href="#">ModSecurity/WAF (coming soon)</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-files">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">File Management</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="#">Admin File Manager (coming soon)</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-installers">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Script Installers</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="#">One-click Apps (coming soon)</a></li>
        </ul>
      </div>
    </div>

    <div class="sidebar-group" data-group-key="admin-session">
      <div class="group-header" role="button" aria-expanded="false">
        <span class="group-label">Session</span>
        <span class="group-arrow">▶</span>
      </div>
      <div class="group-items">
        <ul class="sidebar-nav">
          <li><a href="../logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
